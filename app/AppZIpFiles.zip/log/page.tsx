"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { Store, type RunType } from "../../lib/mcrStore";

function todayYYYYMMDD() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export default function LogPage() {
  const router = useRouter();

  const me = useMemo(() => Store.getMe(), []);
  const [date, setDate] = useState(todayYYYYMMDD());
  const [miles, setMiles] = useState<string>("");
  const [runType, setRunType] = useState<RunType>("training");
  const [raceName, setRaceName] = useState<string>("");
  const [notes, setNotes] = useState<string>("");
  const [shoeId, setShoeId] = useState<string>("");

  const shoes = useMemo(() => Store.listShoes().filter((s) => s.active), []);

  const milesNum = useMemo(() => {
    const n = Number(miles);
    if (!Number.isFinite(n)) return NaN;
    return Math.round(n * 10) / 10;
  }, [miles]);

  const canSave =
    date.length === 10 &&
    Number.isFinite(milesNum) &&
    milesNum > 0 &&
    (runType !== "race" || raceName.trim().length > 0);

  useEffect(() => {
    Store.ensureSeeded();
  }, []);

  function save() {
    if (!canSave) return;

    const created = Store.addRun({
      user_id: me.id,
      run_date: date,
      miles: milesNum,
      run_type: runType,
      race_name: runType === "race" ? raceName.trim() : null,
      notes: notes.trim() ? notes.trim() : null,
      shoe_id: shoeId || null,
    });

    if (created.shoe_id) {
      Store.incrementShoeMiles(created.shoe_id, created.miles);
    }

    router.replace("/home");
  }

  return (
    <div className="px-5 pt-4 pb-28 space-y-5">
      <Card className="p-5">
        <div className="text-[12px] text-black/45 tracking-[0.18em] uppercase">Log a run</div>

        <div className="mt-4 space-y-4">
          <div>
            <label className="text-[12px] text-black/45 tracking-[0.14em] uppercase">Date</label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="mt-2 w-full rounded-2xl border border-black/10 bg-white/70 px-4 py-3 text-[15px] outline-none"
            />
          </div>

          <div>
            <label className="text-[12px] text-black/45 tracking-[0.14em] uppercase">Miles</label>
            <input
              value={miles}
              onChange={(e) => setMiles(e.target.value)}
              inputMode="decimal"
              placeholder="e.g., 3.1"
              className="mt-2 w-full rounded-2xl border border-black/10 bg-white/70 px-4 py-3 text-[15px] outline-none"
            />
            {miles && (!Number.isFinite(milesNum) || milesNum <= 0) ? (
              <div className="mt-2 text-[12px] text-red-600">Enter a valid miles value.</div>
            ) : null}
          </div>

          <div>
            <label className="text-[12px] text-black/45 tracking-[0.14em] uppercase">Type</label>
            <select
              value={runType}
              onChange={(e) => setRunType(e.target.value as RunType)}
              className="mt-2 w-full rounded-2xl border border-black/10 bg-white/70 px-4 py-3 text-[15px] outline-none"
            >
              <option value="training">Training</option>
              <option value="race">Race</option>
              <option value="other">Other</option>
            </select>
          </div>

          {runType === "race" ? (
            <div>
              <label className="text-[12px] text-black/45 tracking-[0.14em] uppercase">Race name</label>
              <input
                value={raceName}
                onChange={(e) => setRaceName(e.target.value)}
                placeholder='e.g., "City 5K"'
                className="mt-2 w-full rounded-2xl border border-black/10 bg-white/70 px-4 py-3 text-[15px] outline-none"
              />
              {!raceName.trim() ? (
                <div className="mt-2 text-[12px] text-black/40">Required for races.</div>
              ) : null}
            </div>
          ) : null}

          <div>
            <label className="text-[12px] text-black/45 tracking-[0.14em] uppercase">Shoe (optional)</label>
            <select
              value={shoeId}
              onChange={(e) => setShoeId(e.target.value)}
              className="mt-2 w-full rounded-2xl border border-black/10 bg-white/70 px-4 py-3 text-[15px] outline-none"
            >
              <option value="">No shoe selected</option>
              {shoes.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
            <div className="mt-2 text-[12px] text-black/40">
              If selected, this run’s miles will be added to the shoe automatically.
            </div>
          </div>

          <div>
            <label className="text-[12px] text-black/45 tracking-[0.14em] uppercase">Notes (optional)</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              placeholder="How did it feel?"
              className="mt-2 w-full rounded-2xl border border-black/10 bg-white/70 px-4 py-3 text-[15px] outline-none resize-none"
            />
          </div>
        </div>

        <div className="mt-6 flex gap-2">
          <Button variant="secondary" onClick={() => router.back()}>Cancel</Button>
          <Button onClick={save} disabled={!canSave}>Save</Button>
        </div>
      </Card>
    </div>
  );
}
