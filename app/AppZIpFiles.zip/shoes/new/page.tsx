"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Card } from "../../../components/ui/Card";
import { Button } from "../../../components/ui/Button";

function uid() {
  return Math.random().toString(16).slice(2) + Date.now().toString(16);
}

type Shoe = {
  id: string;
  name: string;
  miles: number;
  limit: number;
  active: boolean;
};

function readShoes(): Shoe[] {
  try {
    const raw = localStorage.getItem("mcr_shoes");
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeShoes(shoes: Shoe[]) {
  localStorage.setItem("mcr_shoes", JSON.stringify(shoes));
}

export default function AddShoeModalPage() {
  const router = useRouter();

  const [name, setName] = useState("");
  const [limit, setLimit] = useState<string>("400");
  const [saving, setSaving] = useState(false);

  const limitNum = useMemo(() => {
    const n = Number(limit);
    if (!Number.isFinite(n)) return NaN;
    return Math.round(n);
  }, [limit]);

  const canSave = name.trim().length >= 2 && Number.isFinite(limitNum) && limitNum >= 50 && limitNum <= 2000;

  useEffect(() => {
    // prevent background scroll on mobile
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  function close() {
    router.back();
  }

  async function save() {
    if (!canSave) return;
    setSaving(true);

    const shoe: Shoe = {
      id: uid(),
      name: name.trim(),
      miles: 0,
      limit: limitNum,
      active: true,
    };

    const existing = readShoes();
    writeShoes([shoe, ...existing]);

    // tiny delay so the button feels responsive/premium
    setTimeout(() => {
      router.replace("/home");
    }, 250);
  }

  return (
    <div className="fixed inset-0 z-50">
      {/* backdrop */}
      <button
        aria-label="Close"
        onClick={close}
        className="absolute inset-0 bg-black/30 backdrop-blur-[2px]"
      />

      {/* sheet */}
      <div className="absolute inset-x-0 bottom-0">
        <div className="mx-auto max-w-[520px] px-4 pb-[max(16px,env(safe-area-inset-bottom))]">
          <Card className="p-5 rounded-[28px] shadow-[0_30px_90px_rgba(15,23,42,0.25)]">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-[12px] text-black/45 tracking-[0.18em] uppercase">
                  Shoe Mileage
                </div>
                <div className="mt-1 text-[18px] font-semibold tracking-[-0.01em]">
                  Add running shoes
                </div>
                <p className="mt-1 text-[13px] text-black/55 leading-relaxed">
                  Track mileage per pair to know when it’s time to replace them.
                </p>
              </div>

              <button
                onClick={close}
                className="h-10 w-10 rounded-2xl bg-black/5 hover:bg-black/10 active:bg-black/15 transition flex items-center justify-center"
                aria-label="Close"
              >
                <span className="text-[18px] leading-none">×</span>
              </button>
            </div>

            <div className="mt-5 space-y-4">
              <div>
                <label className="text-[12px] text-black/45 tracking-[0.14em] uppercase">
                  Shoe name
                </label>
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder='e.g., "Nike Pegasus 40"'
                  className="mt-2 w-full rounded-2xl border border-black/10 bg-white/70 px-4 py-3 text-[15px] outline-none focus:ring-2 focus:ring-[rgba(var(--accent),0.25)]"
                />
              </div>

              <div>
                <label className="text-[12px] text-black/45 tracking-[0.14em] uppercase">
                  Mileage limit
                </label>
                <div className="mt-2 flex items-center gap-2">
                  <input
                    value={limit}
                    onChange={(e) => setLimit(e.target.value)}
                    inputMode="numeric"
                    placeholder="400"
                    className="w-full rounded-2xl border border-black/10 bg-white/70 px-4 py-3 text-[15px] outline-none focus:ring-2 focus:ring-[rgba(var(--accent),0.25)]"
                  />
                  <div className="text-[13px] text-black/45 whitespace-nowrap pr-1">
                    miles
                  </div>
                </div>
                <div className="mt-2 text-[12px] text-black/40">
                  Typical range is 300–500. Default is <span className="font-medium text-black/55">400</span>.
                </div>

                {!Number.isNaN(limitNum) && (limitNum < 50 || limitNum > 2000) ? (
                  <div className="mt-2 text-[12px] text-red-600">
                    Please choose a limit between 50 and 2000 miles.
                  </div>
                ) : null}
              </div>
            </div>

            <div className="mt-6 flex gap-2">
              <Button variant="secondary" onClick={close}>
                Cancel
              </Button>
              <Button onClick={save} disabled={!canSave || saving}>
                {saving ? "Saving..." : "Save"}
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
