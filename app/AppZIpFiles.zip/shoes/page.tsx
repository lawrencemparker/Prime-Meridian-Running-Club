"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { Store, type Shoe } from "../../lib/mcrStore";

export default function ShoesPage() {
  const router = useRouter();
  const [shoes, setShoes] = useState<Shoe[]>([]);

  function refresh() {
    setShoes(Store.listShoes());
  }

  useEffect(() => {
    refresh();
  }, []);

  function retire(id: string) {
    Store.setShoeActive(id, false);
    refresh();
  }

  function reactivate(id: string) {
    Store.setShoeActive(id, true);
    refresh();
  }

  return (
    <div className="px-5 pt-4 pb-28 space-y-5">
      <Card className="p-5">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[12px] text-black/45 tracking-[0.18em] uppercase">
              Shoe Mileage
            </div>
            <div className="mt-1 text-[18px] font-semibold tracking-[-0.01em]">
              Manage shoes
            </div>
          </div>
          <Button onClick={() => router.push("/shoes/new")}>Add</Button>
        </div>

        <div className="mt-5 space-y-3">
          {shoes.length === 0 ? (
            <div className="text-[13px] text-black/55">
              No shoes yet. Add a pair to start tracking mileage.
            </div>
          ) : (
            shoes.map((s) => (
              <div
                key={s.id}
                className="rounded-2xl bg-white/60 border border-black/5 px-4 py-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-[15px] font-semibold truncate">{s.name}</div>
                    <div className="mt-1 text-[13px] text-black/55">
                      {Math.round(s.miles * 10) / 10} / {s.limit} miles
                      <span className="text-black/40"> · {s.active ? "Active" : "Retired"}</span>
                    </div>
                  </div>

                  {s.active ? (
                    <Button variant="secondary" onClick={() => retire(s.id)}>
                      Retire
                    </Button>
                  ) : (
                    <Button variant="secondary" onClick={() => reactivate(s.id)}>
                      Reactivate
                    </Button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        <div className="mt-6">
          <Button variant="secondary" onClick={() => router.back()}>
            Done
          </Button>
        </div>
      </Card>
    </div>
  );
}
