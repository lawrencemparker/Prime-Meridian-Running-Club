import { GradientHeader } from "../../components/GradientHeader";
import { Card } from "../../components/ui/Card";
import { TabBar } from "../../components/TabBar";

export default function LeaderboardPage() {
  return (
    <div className="pb-28">
      <GradientHeader title="Leaderboard" subtitle="Monthly miles (club only)" />

      <div className="px-5 space-y-4">
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-[13px] text-black/60">Month</div>
              <div className="font-semibold">2026-01</div>
            </div>
            <div className="text-[13px] text-black/60">Club: None</div>
          </div>

          <div className="mt-4 space-y-2">
            {[1, 2, 3, 4, 5].map((rank) => (
              <div
                key={rank}
                className="flex items-center justify-between rounded-2xl bg-black/5 px-3 py-3"
              >
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-full bg-white flex items-center justify-center font-semibold">
                    {rank}
                  </div>
                  <div>
                    <div className="font-semibold">Runner {rank}</div>
                    <div className="text-[12px] text-black/60">Member</div>
                  </div>
                </div>
                <div className="font-semibold">0.0</div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <TabBar />
    </div>
  );
}
