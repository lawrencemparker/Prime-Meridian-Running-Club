"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";

import { Store, Club } from "../../lib/mcrStore";
import { GradientHeader } from "../../components/GradientHeader";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { TabBar } from "../../components/TabBar";

export default function ClubsPage() {
  const router = useRouter();

  const [mounted, setMounted] = useState(false);
  const [premium, setPremium] = useState(false);
  const [activeClubId, setActiveClubId] = useState<string | null>(null);

  useEffect(() => {
    setMounted(true);
    Store.ensureSeeded();

    setPremium(Store.isPremium());

    // Prefer "active", fall back to "approved"
    const active =
      Store.getActiveClubId?.() ??
      Store.getMyApprovedClubId?.() ??
      null;

    setActiveClubId(active);
  }, []);

  const clubs = useMemo<Club[]>(() => {
    if (!mounted) return [];
    return Store.listClubs();
  }, [mounted]);

  function goCreateClub() {
    // ✅ Hard gate at entry point
    if (!Store.isPremium()) {
      router.push("/premium/create-club");
      return;
    }
    router.push("/clubs/create");
  }

  function setActive(clubId: string) {
    Store.setActiveClubId(clubId);
    setActiveClubId(clubId);
    router.push("/home");
  }

  return (
    <div className="pb-28">
      <GradientHeader title="Clubs" subtitle="Find your community and compete together." />

      <div className="px-5 space-y-5 mt-2">
        {/* Create a club (gated) */}
        <Card className="p-5">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0 flex-1">
              <div className="text-[12px] text-black/45 tracking-[0.18em] uppercase">
                Create a club
              </div>
              <div className="mt-1 text-[16px] font-semibold tracking-[-0.01em]">
                Start your own community
              </div>
              <p className="mt-1 text-[13px] text-black/55 leading-relaxed">
                Create clubs, invite runners, post announcements, and view a team leaderboard.
              </p>
            </div>

            {/* Keep this normal width (never vertical) */}
            <div className="shrink-0 pt-1">
              <div className="w-[150px]">
                <Button onClick={goCreateClub}>
                  {premium ? "Create" : "Premium"}
                </Button>
              </div>
            </div>
          </div>
        </Card>

        {/* Browse clubs */}
        {!mounted ? (
          <Card className="p-5">
            <div className="h-4 w-40 rounded-full bg-black/10 animate-pulse" />
            <div className="mt-3 space-y-2">
              <div className="h-12 rounded-2xl bg-black/5 animate-pulse" />
              <div className="h-12 rounded-2xl bg-black/5 animate-pulse" />
              <div className="h-12 rounded-2xl bg-black/5 animate-pulse" />
            </div>
          </Card>
        ) : (
          <Card className="p-5">
            <div className="text-[12px] text-black/45 tracking-[0.18em] uppercase">
              Browse clubs
            </div>

            {clubs.length === 0 ? (
              <div className="mt-3 rounded-2xl bg-black/5 px-4 py-4">
                <div className="text-[14px] font-semibold">No clubs yet</div>
                <p className="mt-1 text-[13px] text-black/55 leading-relaxed">
                  Create the first club to get started.
                </p>
                <div className="mt-4">
                  <Button onClick={goCreateClub}>
                    {premium ? "Create your club" : "Unlock Premium"}
                  </Button>
                </div>
              </div>
            ) : (
              <div className="mt-3 space-y-3">
                {clubs.map((c) => {
                  const isActive = activeClubId === c.id;
                  const badge = c.is_private ? "Private" : "Public";

                  return (
                    <button
                      key={c.id}
                      className="w-full text-left"
                      onClick={() => setActive(c.id)}
                    >
                      <div className="rounded-2xl border border-black/10 bg-white/60 px-4 py-3">
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0">
                            <div className="text-[14px] font-semibold truncate">
                              {c.name}
                            </div>
                            {c.description ? (
                              <div className="mt-0.5 text-[13px] text-black/55 line-clamp-2 leading-relaxed">
                                {c.description}
                              </div>
                            ) : null}
                          </div>

                          <div className="flex flex-col items-end gap-2 shrink-0">
                            <div className="text-[11px] px-2 py-1 rounded-full bg-black/5 text-black/55">
                              {badge}
                            </div>

                            {isActive ? (
                              <div className="text-[11px] px-2 py-1 rounded-full bg-black/10 text-black/70">
                                Active
                              </div>
                            ) : (
                              <div className="text-[11px] text-black/40">Tap to set</div>
                            )}
                          </div>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </Card>
        )}
      </div>

      <TabBar />
    </div>
  );
}
