"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";

import { GradientHeader } from "../../components/GradientHeader";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { TabBar } from "../../components/TabBar";

import { WeatherPill } from "../../components/WeatherPill";
import { ShoeTrackerCard, Shoe } from "../../components/home/ShoeTrackerCard";
import {
  AnnouncementsPreview,
  Announcement,
} from "../../components/home/AnnouncementsPreview";
import { MembersPreview, Member } from "../../components/home/MembersPreview";
import {
  LeaderboardPreview,
  LeaderRow,
} from "../../components/home/LeaderboardPreview";

import { Store } from "../../lib/mcrStore";

export default function HomePage() {
  const router = useRouter();

  // Hydration-safe mount gate (prevents SSR/client mismatch for Store/localStorage reads)
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  // Read Store only after mount
  const me = mounted ? Store.getMe() : null;

  // Preferred: Store exposes an "active" club id (when a club is created/joined)
  // Fallback: approved club id (if that’s what your store uses)
  const activeClubId = mounted ? Store.getActiveClubId?.() ?? null : null;
  const approvedClubId = mounted ? Store.getMyApprovedClubId?.() ?? null : null;

  const clubId = activeClubId ?? approvedClubId;

  const clubName = useMemo(() => {
    if (!mounted || !clubId) return null;
    // If your store has getClubName(clubId), use it; otherwise fall back to lookup
    if (typeof Store.getClubName === "function") return Store.getClubName(clubId);
    const clubs = typeof Store.listClubs === "function" ? Store.listClubs() : [];
    const found = clubs.find((c: any) => c.id === clubId);
    return found?.name ?? null;
  }, [mounted, clubId]);

  // Miles (stub for now; later you’ll compute from logs)
  const monthMiles = 0.0;

  // Shoes come from Store if available; otherwise stub
  const shoes: Shoe[] = useMemo(() => {
    if (!mounted) return [];
    if (typeof Store.listShoes === "function") return Store.listShoes();
    return [
      { id: "s1", name: "Nike Pegasus 40", miles: 212.4, limit: 400, active: true },
      { id: "s2", name: "Saucony Endorphin Speed 3", miles: 344.0, limit: 400, active: true },
    ];
  }, [mounted]);

  // Club-only previews (stub until backend)
  const announcements: Announcement[] = useMemo(
    () => [
      { id: "a1", title: "Saturday long run at 8:00 AM", created_at: "Today" },
      { id: "a2", title: "Track workout moved to Wednesday", created_at: "2 days ago" },
    ],
    []
  );

  const members: Member[] = useMemo(
    () => [
      { id: "m1", full_name: "Miles Parker", phone: "(555) 123-4567", email: "miles@example.com" },
      { id: "m2", full_name: "Avery Johnson", phone: null, email: "avery@example.com" },
      { id: "m3", full_name: "Jordan Lee", phone: "(555) 444-1212", email: null },
      { id: "m4", full_name: "Sam Rivera", phone: null, email: "sam@example.com" },
    ],
    []
  );

  const leaders: LeaderRow[] = useMemo(
    () => [
      { rank: 1, full_name: "Avery Johnson", total_miles: 78.2 },
      { rank: 2, full_name: "Jordan Lee", total_miles: 64.4 },
      { rank: 3, full_name: "Miles Parker", total_miles: 51.0 },
    ],
    []
  );

  return (
    <div className="pb-28">
      <GradientHeader
        title="Good morning"
        subtitle="Let’s make progress today."
        userName={me?.full_name ?? ""}
        clubName={clubName}
      />

      <div className="px-5 space-y-5 mt-2">
        <WeatherPill />

        {/* Month summary */}
        <Card className="p-5">
          <div className="text-[12px] text-black/45 tracking-[0.18em] uppercase">
            This month
          </div>
          <div className="mt-2 text-[30px] font-semibold tracking-[-0.02em]">
            {monthMiles.toFixed(1)} miles
          </div>
          <div className="mt-4">
            <Button onClick={() => router.push("/log")}>Log a Run</Button>
          </div>
        </Card>

        {/* Shoe mileage */}
        <ShoeTrackerCard
          shoes={shoes}
          onAddShoes={() => router.push("/shoes/add")}
          onManageShoes={() => router.push("/shoes")}
        />

        {/* Club-only modules */}
        {clubName ? (
          <>
            <AnnouncementsPreview clubName={clubName} items={announcements} />
            <MembersPreview items={members} />
            <LeaderboardPreview monthLabel="This month" rows={leaders} />
          </>
        ) : (
          <Card className="p-5">
            <div className="text-[12px] text-black/45 tracking-[0.18em] uppercase">
              Clubs
            </div>
            <div className="mt-1 text-[16px] font-semibold tracking-[-0.01em]">
              Join a running club
            </div>
            <p className="mt-1 text-[13px] text-black/55">
              Clubs unlock team leaderboards, announcements, and a member directory.
            </p>
            <div className="mt-4">
              <Button variant="secondary" onClick={() => router.push("/clubs")}>
                Browse clubs
              </Button>
            </div>
          </Card>
        )}
      </div>

      <TabBar />
    </div>
  );
}
